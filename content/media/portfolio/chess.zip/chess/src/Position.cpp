#include "Position.h"

Position::Position(int newrow, int newcol)
{	
	row = newrow;
	col = newcol;
}

Position::Position()
{
}

bool Position::operator<(const Position& checkposition) const
{
	return getValue() < checkposition.getValue();
}
bool Position::operator>(const Position& checkposition) const
{
	return getValue() > checkposition.getValue();
}
bool Position::operator==(const Position& checkposition) const
{
	return getValue() == checkposition.getValue();
}

int Position::getValue() const
{
	return(8*row)+col;
}


int Position::getRow()
{
	return row;
}

int Position::getCol()
{
	return col;
}




