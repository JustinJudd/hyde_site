#include "Rook.h"
#include <stdio.h>
#include "Pieces.h"

using namespace std;

Rook::Rook(colors newcolor, Position newposition): Piece(newcolor, newposition)
{
	type = rook;
}


set<Move> Rook::getMoves(Board &currentboard)
{
	//int checkrow;
	//int checkcol = current.getCol();

	set<Move> moves;
	set<Position> positions;
	set<Position>::iterator positer;
	positions=getLinearPositions(currentboard);
	//cout << "Possible Moves: " << positions.size() << endl;

	for(positer = positions.begin(); positer!=positions.end(); positer++)
	{
		Position temp = *positer;
		if(currentboard.getSquare(temp)->containsPiece())
		{
			Piece * piece = currentboard.getSquare(temp)->getPiece();
			moves.insert(createMove(temp, piece->getType()));
		}
		else moves.insert(createMove(temp));
	
	}
	
	return moves;
}

bool Rook::Test(ostream &os)
{

	//Rook will be white, will be either at (1,0)
	bool validmoves = false;

	Board board = Board();
	Position start = Position(1,0);
	Piece * testrook = new Rook(white, start);

	Square * place = board.getSquare(start);
	
	Position other = Position(1,5);
	Piece * pawnpiece = new Pawn(white, other);
	Piece * rookpiece = new Rook(black, other);

	Square * otherplace = board.getSquare(other);

	place->setPiece(testrook);

	set<Move> testmoves = testrook->getMoves(board);

	if(testmoves.size() ==14)
		validmoves = true;
	else os << "Rook Test Case 1 failed" << endl;

	otherplace->setPiece(pawnpiece);

	testmoves = testrook->getMoves(board);

	if(testmoves.size() ==11 &&validmoves)
		validmoves = true;
	else
	{
		if(validmoves)
			os << "Rook Test Case 2 failed" << endl;
		validmoves = false;	
	}
		
	otherplace->setPiece(rookpiece);

	testmoves = testrook->getMoves(board);
	if(testmoves.size() ==12 &&validmoves)
	{
		validmoves = true;

	}
	else
	{
		if(validmoves)
			os << "Rook Test Case 3 failed" << endl;
		validmoves = false;
	}
	return validmoves;

}

