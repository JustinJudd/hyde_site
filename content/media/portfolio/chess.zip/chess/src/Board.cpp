#include "Board.h"
#include "Square.h"

Board::Board()
{
	/*for(int i=0; i<BOARD_SIZE; i++)
	{
		for(int j=0; j<BOARD_SIZE;j++)
		{
			squares[i][j]
		}
	}*/
	//cout << "Board Created" << endl;
	
}

Square * Board::getSquare(Position checkposition)
{
	return &squares[checkposition.getRow()][checkposition.getCol()];
}


