#ifndef CHESSQueen_H
#define CHESSQueen_H

#include <set>
#include "Move.h"
#include "Piece.h"
#include "Enums.h"


class Queen: public Piece
{

	public:

	Queen(colors newcolor, Position newposition);
	
	virtual set<Move> getMoves(Board &currentboard);
	/* 	find the valid moves for the piece
		parameter: none
		returns: set of valid Move objects
	*/
		
	static bool Test(ostream &os);	
};


#endif



