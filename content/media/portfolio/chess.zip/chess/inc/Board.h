#ifndef CHESSBoard_H
#define CHESSBoard_H

//#include "Piece.h"
#include "Position.h"
#include "Square.h"
#include <stdio.h>
#include <string>
#include <iostream>

//class Square;

using namespace std;

#define BOARD_SIZE 8;//board row and width


class Board
{

	public:

	Board();//initialize board to blank squares
	
	//~Board();

	//Piece * getPiece(Position checkposition);
	
	/* 	get pointer to square at a specific position
		parameter: position to know which square
		returns: pointer to the square at the given position
	*/
	Square * getSquare(Position checkposition);
	
	string save();
	/* 	get the board data in xml format to save it
		parameter: none
		returns: string of bard data in xml format
	*/

	//void load(); 

	private:
	//Square squares[BOARD_SIZE][BOARD_SIZE];//Set up 2d array of squares
	Square squares[8][8];//Set up 2d array of squares
};	


#endif



