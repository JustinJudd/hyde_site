#ifndef CHESSPiece_H
#define CHESSPiece_H

#include "Enums.h"
#include "Move.h"
#include "Board.h"
#include "Position.h"
#include "Square.h"
#include <set>
#include <iostream>

//enum colors{white, black};
//enum PieceType{pawn, knight, bishop, rook, queen, king};
using namespace std;

class Piece
{
	public:
	//enum color_options{white, black};
	Piece();	

	Piece(colors newcolor, Position newposition);
	/* 	Initialize Piece object
		parameter: color of piece, the position of the piece, and the type of the piece
		returns: none
	*/


	virtual set<Move> getMoves(Board &currentboard)=0;//This will be implemented by each piece type
	/* 	find the valid moves the piece can make
		parameter: the current board state
		returns: set of valid Move objects
	*/

	set<Position> getLinearPositions(Board &board);
	set<Position> getDiagonalPositions(Board &board);
	bool movevalid(Board board, Position moveto);

	set<Position> LinearUpnDown(Board &board);
	set<Position> LinearLeftnRight(Board &board);
	set<Position> DiagonalUp(Board &board);
	set<Position> DiagonalDown(Board &board);
	
	set<Position> mergePositions(set<Position> firstset, set<Position> secondset);

	colors getColor();
	
	PieceType getType();

	Position getCurrentPlace();
	
	Position getPreviousPlace();
	void setCurrentPlace(Position place);
	
	bool movedYet();

	Move createMove(Position movehere, PieceType capturedtype);
	Move createMove(Position movehere);

	void Moving(Position moveto);

	//static bool Test(ostream &os);

	protected:
	colors color;//the color of the piece
	Position current; //the position where the piece currently is
	Position previous; //Position where piece previously was
	PieceType type; //Type of this piece
	bool moved;
};

#endif



