#ifndef CHESSEnums_H
#define CHESSEnums_H

enum colors{white, black};
enum PieceType{pawn, knight, bishop, rook, queen, king};


#endif



