#include "Queen.h"
#include "Pieces.h"

Queen::Queen(colors newcolor, Position newposition): Piece(newcolor, newposition)
{
	type = queen;
}


set<Move> Queen::getMoves(Board &currentboard)
{
	set<Move> moves;
	set<Position> positions;
	set<Position>::iterator positer;
	positions=getLinearPositions(currentboard);

	for(positer = positions.begin(); positer!=positions.end(); positer++)
	{
		Position temp = *positer;
		if(currentboard.getSquare(temp)->containsPiece())
		{
			Piece * piece = currentboard.getSquare(temp)->getPiece();
			moves.insert(createMove(temp, piece->getType()));
		}
		else moves.insert(createMove(temp));

	}

	positions=getDiagonalPositions(currentboard);

	for(positer = positions.begin(); positer!=positions.end(); positer++)
	{
		Position temp = *positer;
		if(currentboard.getSquare(temp)->containsPiece())
		{
			Piece * piece = currentboard.getSquare(temp)->getPiece();
			moves.insert(createMove(temp, piece->getType()));
		}
		else moves.insert(createMove(temp));

	}

	
	return moves;

}

bool Queen::Test(ostream &os)
{

	//Queen will be white, will be at (1,0)
	bool validmoves = false;
	Position start = Position(1,0);
	Piece * testqueen = new Queen(white, start);
	Board board = Board();

	Square * place = board.getSquare(start);
	
	Position other = Position(4,3);
	Piece * pawnpiece = new Pawn(white, other);
	Piece * rookpiece = new Rook(black, other);

	Square * otherplace = board.getSquare(other);

	place->setPiece(testqueen);

	set<Move> testmoves = testqueen->getMoves(board);
	//cout << testmoves.size() << endl;
	if(testmoves.size() ==21)
		validmoves = true;
	else os << "Queen Test Case 1 failed" << endl;

	otherplace->setPiece(pawnpiece);

	testmoves = testqueen->getMoves(board);

	if(testmoves.size() ==17 &&validmoves)
		validmoves = true;
	else 
	{
		if(validmoves)
			os << "Queen Test Case 2 failed" << endl;
		validmoves = false;
	}
		
	otherplace->setPiece(rookpiece);

	testmoves = testqueen->getMoves(board);
	if(testmoves.size() ==18 &&validmoves)
	{
		validmoves = true;

	}
	else
	{
		if(validmoves)
			os << "Queen Test Case 3 failed" << endl;
		validmoves = false;
	}
	

	return validmoves;

}

