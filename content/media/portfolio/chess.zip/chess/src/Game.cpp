#include "Game.h"
#include "Enums.h"
#include "Piece.h"
#include "Board.h"
#include "Position.h"
#include "Move.h"
#include <set>
#include <string>
#include <list>
#include "XMLParser.h"
#include <iostream>
#include <stdio.h>
#include "Pieces.h"

using namespace std;
	
Game::Game()
{
	gameboard = Board();
	createPieces();

	blackstalemate = false;
	blackcheckmate = false;
	whitestalemate = false;
	whitecheckmate = false;

	whitecheck = false;
	blackcheck = false;
	//cout << "Pieces Created" << endl;
	//gameboard * = new Board();
	//gameboard = Board();
	setTurn(white);
	chosenpiece = NULL;
}

Game::~Game()
{
	clearGame();
	//delete[] pieces;
	//
	//delete chosenpiece;
	//for(int i=0;i<32; i++)
	//{	delete pieces[i];
	//	pieces[i] = NULL;
	//}
	//pieces = NULL;
	//chosenpiece =NULL;

/*	for(int row=0; row<8;row++)
	{
		for(int col=0;col<8;col++)
		{
			Position checkplace = Position(row,col);
			if(hasPiece(checkplace))
			{
				Piece * deleteme = getPiece(checkplace);
				if(deleteme !=NULL)
				{
					delete deleteme;
					deleteme = NULL;
				}
			}
		}

	}
*/
}

void Game::clearGame()
{
	for(int row=0; row<8;row++)
	{
		for(int col=0;col<8;col++)
		{
			Position checkplace = Position(row,col);
			if(hasPiece(checkplace))
			{
				Piece * deleteme = getPiece(checkplace);
				if(deleteme !=NULL)
				{
					delete deleteme;
					deleteme = NULL;
				}
			}
		}

	}

}

void Game::createPieces()
{
		
	
	//White Pieces
	//Piece * pieces[32];
	Position initial[32];
	getInitPositions(initial);
	PieceType types[32];
	getInitTypes(types);
	

	for(int i=0; i<16; i++)
	{
		pieces[i] = createPiece(white,types[i], initial[i]);
		gameboard.getSquare(initial[i])->setPiece(pieces[i]);
	}
	for(int i=16; i<32; i++)
	{
		pieces[i] = createPiece(black,types[i], initial[i]);
		gameboard.getSquare(initial[i])->setPiece(pieces[i]);
	}

}

void Game::getInitPositions(Position initial[])
{
	//Position initial[32];
	//white positions
	initial[0] = Position(6,0);
	initial[1] = Position(6,1);
	initial[2] = Position(6,2);
	initial[3] = Position(6,3);
	initial[4] = Position(6,4);
	initial[5] = Position(6,5);
	initial[6] = Position(6,6);
	initial[7] = Position(6,7);
	initial[8] = Position(7,0);
	initial[9] = Position(7,1);
	initial[10] = Position(7,2);
	initial[11] = Position(7,3);
	initial[12] = Position(7,4);
	initial[13] = Position(7,5);
	initial[14] = Position(7,6);
	initial[15] = Position(7,7);

	//black positions
	initial[16] = Position(1,0);
	initial[17] = Position(1,1);
	initial[18] = Position(1,2);
	initial[19] = Position(1,3);
	initial[20] = Position(1,4);
	initial[21] = Position(1,5);
	initial[22] = Position(1,6);
	initial[23] = Position(1,7);
	initial[24] = Position(0,0);
	initial[25] = Position(0,1);
	initial[26] = Position(0,2);
	initial[27] = Position(0,3);
	initial[28] = Position(0,4);
	initial[29] = Position(0,5);
	initial[30] = Position(0,6);
	initial[31] = Position(0,7);

}

void Game::getInitTypes(PieceType types[])
{
	//white pieces
	types[0] = pawn;
	types[1] = pawn;
	types[2] = pawn;
	types[3] = pawn;
	types[4] = pawn;	
	types[5] = pawn;
	types[6] = pawn;
	types[7] = pawn;
	types[8] = rook;
	types[9] = knight;
	types[10] = bishop;
	types[11] = queen;
	types[12] = king;
	types[13] = bishop;
	types[14] = knight;
	types[15] = rook;

	//black pieces
	types[16] = pawn;
	types[17] = pawn;
	types[18] = pawn;
	types[19] = pawn;
	types[20] = pawn;	
	types[21] = pawn;
	types[22] = pawn;
	types[23] = pawn;
	types[24] = rook;
	types[25] = knight;
	types[26] = bishop;
	types[27] = queen;
	types[28] = king;
	types[29] = bishop;
	types[30] = knight;
	types[31] = rook;

}


void Game::getPieces(Piece ** &returnpieces)
{
	
	returnpieces = pieces;

	for(int i=0; i<32; i++)
	{
		returnpieces[i] = pieces[i];
	}

}

Board * Game::getBoard()
{
	return &gameboard;
}

void Game::movePiece(Piece * piece, Position place, Move move)
{
	piece->Moving(place);
	MoveHistory.push_back(move);
	switchTurn();
}

void Game::setTurn(colors newcolor)
{
	turncolor = newcolor;
}

void Game::switchTurn()
{
	if(turncolor == white)
		turncolor=black;
	else turncolor = white;
}

colors Game::getTurn()
{
	return turncolor;
}

set<Move> Game::getValidMoves()
{
	//set<Move> templist = ValidMoves;
	set<Move> invalidmoves;

	set<Move>::iterator moveiter;
	//Piece * temppiece = chosenpiece;
	//cout << "Possible Moves(should be highlighted now: " << ValidMoves.size() << endl;
	for(moveiter = ValidMoves.begin(); moveiter!=ValidMoves.end(); moveiter++)
	{
		Move tempmove = *moveiter;
		Board testboard = gameboard;
		
		Position oldplace = tempmove.getOldPosition();
		Position newplace = tempmove.getNewPosition();
		Piece * piece = testboard.getSquare(oldplace)->getPiece();
		testboard.getSquare(oldplace)->removePiece();
		testboard.getSquare(newplace)->setPiece(piece);
		piece->setCurrentPlace(newplace);
		//cout << "can move to: " << newplace.getRow() << ", " << newplace.getCol() << endl;

			if(checkForCheck(piece->getColor(), testboard))
			{
				//cout << "Above move appears to be invalid" << endl;				
				invalidmoves.insert(tempmove);
			}
			
			chosenpiece->setCurrentPlace(oldplace);
	}
	removeMoves(invalidmoves, ValidMoves);
	//setGameStatus(turncolor);
	//chosenpiece = temppiece;
	
	//ValidMoves = templist;
	
	return ValidMoves;
}

set<Move> Game::getValidMoves(set<Move> moves)
{
	//set<Move> templist = ValidMoves;
	set<Move> invalidmoves;

	set<Move>::iterator moveiter;
	//Piece * temppiece = chosenpiece;

	for(moveiter = moves.begin(); moveiter!=moves.end(); moveiter++)
	{
		Move tempmove = *moveiter;
		Board testboard = gameboard;
		
		Position oldplace = tempmove.getOldPosition();
		Position newplace = tempmove.getNewPosition();
		//cout << "Move would go from: " << oldplace.getRow() << ", " << oldplace.getCol() << endl;

		//cout << "Move would go to: " << newplace.getRow() << ", " << newplace.getCol() << endl;

		if(testboard.getSquare(oldplace)->getPiece())
		{	
			//cout << "Piece is at this spot"  << endl;
			Piece * piece = testboard.getSquare(oldplace)->getPiece();
			testboard.getSquare(oldplace)->removePiece();
			testboard.getSquare(newplace)->setPiece(piece);
			piece->setCurrentPlace(newplace);
			//cout << "can move to: " << newplace.getRow() << ", " << newplace.getCol() << endl;

				if(checkForCheck(piece->getColor(), testboard))
				{
					//cout << "Above move appears to be invalid" << endl;				
					invalidmoves.insert(tempmove);
				}
			piece->setCurrentPlace(oldplace);	
		}
			//if(chosenpiece != NULL)
			//	chosenpiece->setCurrentPlace(oldplace);
	}
	removeMoves(invalidmoves, moves);
	//setGameStatus(turncolor);
	//chosenpiece = temppiece;
	
	//ValidMoves = templist;
	
	return moves;
}


void Game::clearValidMoves()
{
	ValidMoves.clear();
}

bool Game::getMoves(Position chosen)
{
	bool pieceSelected = false;
	Square * thissquare = gameboard.getSquare(chosen);
	Piece * thispiece = thissquare->getPiece();
	if(thissquare->containsPiece() && getTurn()==thispiece->getColor())
	{
		pieceSelected = true;
		chosenpiece = thispiece;
			
		ValidMoves=thispiece->getMoves(gameboard);
		
	}
	return pieceSelected;
}

Piece * Game::getChosenPiece()
{
	return chosenpiece;	
}

bool Game::hasPiece(Position position)
{
	Square * square = gameboard.getSquare(position);
	return square->containsPiece();
}	

Piece * Game::getPiece(Position position)
{
	Square * square = gameboard.getSquare(position);
	return square->getPiece();
}

bool Game::isValidMove(Position chosen, Position before)
{
	bool found = false;
	set<Move>::iterator find;
	Move possmove = Move(chosenpiece->getType(),chosenpiece->getColor(),before,chosen);
	find=ValidMoves.find(possmove);

	if(find!=ValidMoves.end())
	{
		possmove = *find;
		found = true;
		if(possmove.didCapture())
		{
			//cout << "This move is valid and captures a piece" << endl;
			Piece * deleteme = getPiece(chosen);
			delete deleteme;
			deleteme = NULL;

		}
		movePiece(chosenpiece,chosen, possmove);
		gameboard.getSquare(before)->removePiece();
		gameboard.getSquare(chosen)->setPiece(chosenpiece);
		//do something to check if enemy king is in check here
		//setGameStatus(turncolor);
		
		clearValidMoves();

		colors checkcolor;
		if(chosenpiece->getColor() == white)
			checkcolor = black;
		else checkcolor= white;
	
		//if(checkForCheck(checkcolor))
		if(checkForCheck(checkcolor, gameboard))
		{
			//cout << "Player is in check" << endl;
			if(checkcolor == white)
				whitecheck = true;
			else blackcheck = true;
			//templist.erase(tempmove);
			//if(templist.size()==0)
			//	checkmate = true;
		}
		else
		{
			whitecheck = false;	
			blackcheck = false;

		}
	
		setGameStatus(checkcolor);

	}
	

	return found;
}

Move Game::undoMove()
{
	Move returnmove = MoveHistory.back();
	MoveHistory.pop_back();
	
	Position now = returnmove.getNewPosition();
	Position backto = returnmove.getOldPosition();

	Piece * moving =gameboard.getSquare(now)->getPiece();
	moving->setCurrentPlace(backto);
	gameboard.getSquare(now)->removePiece();
	gameboard.getSquare(backto)->setPiece(moving);
	switchTurn();

	if(returnmove.didCapture())
	{
		Piece * captured = createPiece(returnmove.getCapturedColor(), returnmove.getCapturedPiece(), now);
		gameboard.getSquare(now)->setPiece(captured);
	}
	//clearValidMoves();
	return returnmove;
}

Piece * Game::createPiece(colors newcolor, PieceType newtype, Position starting)
{
	Piece * newpiece;
	if(newtype==pawn)
		newpiece = new Pawn(newcolor, starting);
	if(newtype==knight)
		newpiece = new Knight(newcolor, starting );
	if(newtype==bishop)
		newpiece = new Bishop(newcolor, starting );
	if(newtype==rook)
		newpiece = new Rook(newcolor, starting);
	if(newtype==queen)
		newpiece = new Queen(newcolor, starting );
	if(newtype==king)
		newpiece = new King(newcolor, starting);

	return newpiece;
}

int Game::getHistorySize()
{
	return MoveHistory.size();
}

string Game::getBoardXML()
{
	stringstream xmlstream;
	string xmlout;
	
	xmlstream << "\t<board>" << endl;
	for(int row=0; row<8; row++)
	{
		for(int col=0; col<8;col++)
		{
			Position test = Position(row, col);
			Square * square = gameboard.getSquare(test);
			if(square->containsPiece())
			{
				Piece * temp = square->getPiece();
				xmlstream << pieceXML(temp->getType(),temp->getColor(), test );
			}
		}
	}
	xmlstream << "\t</board>" << endl;
	xmlout = xmlstream.str();

	return xmlout;
}

string Game::getMoveXML()
{
	stringstream xmlstream;
	string xmlout;
	list<Move>::iterator iter;
	
	
	xmlstream << "<history>" << endl;
	for(iter=MoveHistory.begin(); iter!=MoveHistory.end(); iter++)
	{
		xmlstream << "\t<move>" << endl;
		Move move = *iter;
		Position oldpos = move.getOldPosition();
		Position newpos = move.getNewPosition();
		
		xmlstream << pieceXML(move.getPieceType(), move.getColor(), oldpos);
		xmlstream << pieceXML(move.getPieceType(), move.getColor(), newpos);
		if(move.didCapture())
			xmlstream << pieceXML(move.getCapturedPiece(), move.getCapturedColor(), newpos);


		xmlstream << "\t</move>" << endl;
	}
	xmlstream << "\n</history>" << endl;
	xmlout = xmlstream.str();

	return xmlout;


}

string Game::pieceXML(PieceType ptype, colors pcolor, Position ppos)
{
	stringstream xmlstream;
	string xmlout;

	xmlstream << "\t\t<piece ";
	xmlstream << "type=\"" << typeToText(ptype) << "\" " ;
	xmlstream << "color=\"" << colorToText(pcolor)<< "\" ";
	xmlstream << "column=\"" << ppos.getCol() << "\" ";
	xmlstream << "row=\"" << ppos.getRow() << "\" ";
	xmlstream << "/>" << endl;
	xmlout = xmlstream.str();

	return xmlout;
}

string Game::typeToText(PieceType convert)
{
	string outtext;
	switch(convert)
	{
		case pawn:
			outtext = "pawn";	
		break;

		case knight:
			outtext = "knight";
		break;

		case bishop:
			outtext = "bishop";
		break;

		case rook:
			outtext = "rook";
		break;
		
		case queen:
			outtext = "queen";
		break;

		case king:
			outtext = "king";
		break;

	}

	return outtext;
}

string Game::colorToText(colors convert)
{
	string outtext;
	switch(convert)
	{
		case white:
			outtext = "white";	
		break;

		case black:
			outtext = "black";
		break;
	}
	return outtext;
}

void Game::parseXML(string data)
{
	parser = new XMLParser(data);
	
	gameboard = parser->getBoard();
	MoveHistory = parser->getHistory();	
	//cout << "New History Size: " << MoveHistory.size() << endl;

	if(MoveHistory.size() != 0)
	{
		Move lastmove = MoveHistory.back();
		colors lastturn = lastmove.getColor();
		setTurn(lastturn);
		switchTurn();
	}
	else setTurn(white);
	
	
	//parser = new XMLParser("test");
	delete parser;
}

bool Game::checkForCheck(colors piececolor)
{

	bool returnvalue = false;
	Position kinghere;
	//if(piececolor == white)
	//	kinghere = findKing(black);
	//else kinghere = findKing(white);

	kinghere = findKing(piececolor);

	for(int row =0; row<8; row++)
	{
		for(int col=0; col<8; col++)
		{
			Position checkplace = Position(row, col);
			if(hasPiece(checkplace))
			{
				Piece * temppiece = getPiece(checkplace);
				if(temppiece->getColor() != piececolor)
				{
					set<Move> moves = temppiece->getMoves(gameboard);
					if(wouldCapture(kinghere, moves))
					{
						returnvalue= true;
					}
				}
				
			}
		}
	}

	return returnvalue;
}

bool Game::wouldCapture(Position kinghere, set<Move> moves)
{
	bool returnvalue = false;
	set<Move>::iterator moveiter;
	for(moveiter = moves.begin(); moveiter!=moves.end(); moveiter++)
	{
		Move tempmove = *moveiter;
		Position newplace = tempmove.getNewPosition();
		if(newplace == kinghere)
		{
			returnvalue = true;
		}
	}

	return returnvalue;
}

Position Game::findKing(colors color)
{
	Position kinghere;
	for(int row =0; row<8; row++)
	{
		for(int col=0; col<8; col++)
		{
			Position checkplace = Position(row, col);
			if(hasPiece(checkplace))
			{
				Piece * temppiece = getPiece(checkplace);
				if(temppiece->getColor() == color && temppiece->getType() == king)
				{
					kinghere = checkplace;	
				}
				
			}
		}
	}

	return kinghere;

}

Position Game::findKing(colors color, Board board)
{
	Position kinghere;
	for(int row =0; row<8; row++)
	{
		for(int col=0; col<8; col++)
		{
			Position checkplace = Position(row, col);
			if(board.getSquare(checkplace)->containsPiece())
			{
				Piece * temppiece = board.getSquare(checkplace)->getPiece();
				if(temppiece->getColor() == color && temppiece->getType() == king)
				{
					kinghere = checkplace;	
				}
				
			}
		}
	}

	return kinghere;

}



bool Game::getCheckStatus(colors color)
{
	if(color == white && whitecheck)
		return true;
	else if (color == black && blackcheck)
		return true;
	else return false;
}

bool Game::getCheckStatus()
{
	if(turncolor == white && whitecheck)
		return true;
	else if (turncolor == black && blackcheck)
		return true;
	else return false;
}


bool Game::checkForCheck(colors piececolor, Board board)
{

	bool returnvalue = false;
	Position kinghere;
	/*if(chosenpiece != NULL)
	{
		if(chosenpiece->getType() == king)
			kinghere = chosenpiece->getCurrentPlace();
		else kinghere = findKing(piececolor);
	}
	else kinghere = findKing(piececolor);
	*/
	kinghere = findKing(piececolor, board);

	for(int row =0; row<8; row++)
	{
		for(int col=0; col<8; col++)
		{
			Position checkplace = Position(row, col);
			if(board.getSquare(checkplace)->containsPiece())
			{

				Piece * temppiece = board.getSquare(checkplace)->getPiece();
				
				if(temppiece->getColor() != piececolor)
				{
					set<Move> moves = temppiece->getMoves(board);
					if(wouldCapture(kinghere, moves))
					{
						//cout << "Piece: " << temppiece->getType() << " can capture king" << endl;
						returnvalue= true;
					}
				}
				
			}
		}
	}

	return returnvalue;
}


void Game::removeMoves(set<Move> invalid, set<Move> &moves)
{
	set<Move>::iterator iter;
	for(iter = invalid.begin(); iter!=invalid.end(); iter++)
	{
		 	
		Move remove = *iter;
		
		moves.erase(remove);		
	}
}

bool Game::colorCanMove(colors color)
{
	bool canmove = false;

	for(int row=0;row<8; row++)
	{
		for(int col=0; col<8; col++)
		{
			Position checkplace = Position(row, col);
			if(hasPiece(checkplace))
			{
				Piece * temp = getPiece(checkplace);
				if(temp->getColor() == color)
				{
					set<Move> moves = temp->getMoves(gameboard);
					//cout << "Moves size: " << moves.size() << endl;
					moves = getValidMoves(moves);
					if(moves.size() != 0)
					{
						//cout << "Player has possible moves" << endl;
						//cout << "With Piece: " << temp->getType() << endl;
						//cout << "Possible moves: " << moves.size() << endl;
						
						canmove = true;
						row = 8;
						col= 8;
					}

				}

			}


		}
	}
	/*if(!canmove)
		cout<< "player has no valid moves" << endl;
	else cout << "apparently, player can move" << endl;
	*/
	
	return canmove;

}

void Game::setGameStatus(colors color)
{

	bool canmove = colorCanMove(color);
	
	blackstalemate = false;
	blackcheckmate = false;
	whitestalemate = false;
	whitecheckmate = false;
	
	//if(!canmove && )

	if(turncolor ==white && !canmove)
	{
		if(whitecheck)
			whitecheckmate = true;
		else whitestalemate = true;

	}
	else if(turncolor==black && !canmove)
	{
		if(blackcheck)
			blackcheckmate = true;
		else blackstalemate = true;
	}
}

bool Game::inCheckMate()
{	
	if(turncolor == white)
		return whitecheckmate;
	else return blackcheckmate;

}

bool Game::inStaleMate()
{
	if(turncolor == white)
		return whitestalemate;
	else return blackstalemate;

}
