//#include "Test.h"
#include "Position.h"
#include <set>
#include "Move.h"
#include "Enums.h"
#include <iostream>
//#include <stdio.h>
#include "Pieces.h"
#include "Piece.h"
#include <ostream>

using namespace std;
int main()
{
	bool success = true;
	//ostream os;
	
	if(!Pawn::Test(cout))
	{
		success = false;
		cout << "Pawn Moves Failed" << endl;
		//cout << os.rdbuf();
	}
	if(!Knight::Test(cout))
	{
		success = false;
		cout << "Knight Moves Failed" << endl;
		//cout << os.rdbuf();
	}
	if(!Bishop::Test(cout))
	{
		success = false;
		cout << "Bishop Moves Failed" << endl;
		//cout << os.rdbuf();
	}
	if(!Rook::Test(cout))
	{
		success = false;
		cout << "Rook Moves Failed" << endl;
		//cout << os.rdbuf();
	}
	if(!Queen::Test(cout))
	{
		success = false;
		cout << "Queen Moves Failed" << endl;
		//cout << os.rdbuf();
	}
	if(!King::Test(cout))
	{
		success = false;
		cout << "King Moves Failed" << endl;
		//cout << os.rdbuf();
	}

	if(success)
		cout << "Congratulations, All tests passed" << endl;
	return 0;
}
