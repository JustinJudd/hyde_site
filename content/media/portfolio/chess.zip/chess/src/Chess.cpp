// Author: Owen Merkling,,, <omerkling@gmail.com>, (C) 2008
// Contributor:  Justin Judd
//
// Copyright: For use by the students of CS 240 at BYU
//
//

#include <set>
#include <iostream>
#include "SelectDialog.h"
#include "Chess.h"
#include "Game.h"
#include <sstream>
#include <fstream>
#include <string>

using namespace std;

Chess::Chess(std::string gladefile):gui(0),logId(0)
{
	Glib::RefPtr<Gnome::Glade::Xml> chessXml = Gnome::Glade::Xml::create(gladefile);
	chessXml->get_widget_derived("Chess_Main",gui);
	
	gui->signal_cell_selected().connect(sigc::mem_fun(*this,&Chess::on_CellSelected));
	
	
	gui->signal_new().connect(sigc::mem_fun(*this,&Chess::on_NewGame));
	gui->signal_save().connect(sigc::mem_fun(*this,&Chess::on_SaveGame));
	gui->signal_save_as().connect(sigc::mem_fun(*this,&Chess::on_SaveGameAs));
	gui->signal_load().connect(sigc::mem_fun(*this,&Chess::on_LoadGame));
	gui->signal_undo().connect(sigc::mem_fun(*this,&Chess::on_UndoMove));
	gui->signal_quit().connect(sigc::mem_fun(*this,&Chess::on_QuitGame));
	
	
	gui->signal_drag_start().connect(sigc::mem_fun(*this,&Chess::on_DragStart));
	gui->signal_drag_end().connect(sigc::mem_fun(*this,&Chess::on_DragEnd));
	
	//Set g_log to print to the message area
	logId = g_log_set_handler(0,GLogLevelFlags(G_LOG_LEVEL_MASK| G_LOG_FLAG_FATAL| G_LOG_FLAG_RECURSION),log_handler,gui);
	


	//some examples, may be deleted*********

	gui->WriteMessageArea("Awesome Chess Ready!\n");
	gui->WriteMessageArea("Set!\nGo!\n");
	/*gui->WriteMessageArea(
	"Some of the features of the using the GUI are shown as an example. They may be viewed and then deleted from the 'Chess' constructor"); */
	gui->SetStatusBar("StatusBar");
	gui->SetTopLabel("Black");
	gui->SetBottomLabel("White");
	
	//gui->PlacePiece(0,0,B_ROOK);
	//gui->PlacePiece(7,7,W_ROOK);
	/*
	gui->HighlightSquare(4,4,RED_SQUARE);
	gui->HighlightSquare(4,5,GREEN_SQUARE);
	gui->HighlightSquare(5,4,0xFF00FFAA);   //a one time custom color using hexadecimal
	gui->HighlightSquare(5,5,0xFB9312FF); 
	*/
	//***************************************
	//set your init code here***********************************************************
	//Game * game = new Game();
	game = new Game();
	placePieces();
	pieceSelected = false;
	gui->SetStatusBar("White's Turn");
	

	//**********************************************************************************
}

Chess::~Chess()
{
	//set you clean up code here****

	delete game;
	game = NULL;


	//******************************
	g_log_remove_handler(0,logId);//remove reference to data
	delete gui;
	gui=0;
	


}



/********Implement These*****************************/


void Chess::on_CellSelected(int row, int col, int button)
{
	//g_debug("Chess::on_CellSelected (%d,%d)",row,col);
	
	set<Move> validmoves=game->getValidMoves();	
	//set<Move>::iterator moveiter;
	Position clicked = Position(row,col);
	//if(!pieceSelected)
	if(validmoves.size() ==0 )
	{
		//g_debug("Piece Selected");
		Position clicked = Position(row,col);
		pieceSelected =game->getMoves(clicked);
			
		if(pieceSelected)
		{
			validmoves = game->getValidMoves();
			highlightMoves(validmoves);
			
		}
	}
	else
	{
		//g_debug("Checking if valid Move\n");
		Position before = game->getChosenPiece()->getCurrentPlace();
		//if(before == clicked)
		//{
		//}

		if(game->isValidMove(clicked, before))
		{
			ImageName image;
			image = getImageName(game->getChosenPiece());
			gui->ClearPiece(before.getRow(),before.getCol());
			gui->PlacePiece(row, col, image);
			unHighlightMoves(validmoves);
			if(game->getTurn() == white)
				gui->SetStatusBar("White's Turn");
			else gui->SetStatusBar("Black's Turn");

			if(game->getCheckStatus())
				g_message("Check");
			if(game->inCheckMate() || game->inStaleMate())
			{
				gui->SetStatusBar("Game Over!");
				if(game->inCheckMate())
					g_message("CheckMate");
				else g_message("StaleMate");

			}
				
		}
		unHighlightMoves(validmoves);
		game->clearValidMoves();

		
	}

	
	/*
	  Each square of the chess board is reffered to in the GUI code as a cell.
	This Function is called whenever the uses clicks and releases the mous button over
	a cell without initiating a drag. Row and Column coordinates begin in the top left corner.
	The button paramter tells which mouse button was clicked(1 for left, 2 for middle, 3 for right).
	You do not need to worry about wich button was used to complete the project.
	*/
}

void Chess::on_DragStart(int row,int col)
{
	//g_debug("Chess::on_DragStart (%d,%d)",row,col);
	/*
	  When a drag is initiated, this function will be called instead of on_CellSelected().
	The paramaters row and col are the coordinates of the cell where the drag was initiated.
	All three buttons may initiate the drag, but for our purposes can be treated the same and so
	that paramater is not included.
	*/
}
bool Chess::on_DragEnd(int row,int col)
{
	//g_debug("Chess::on_DragEnd (%d,%d)",row,col);
	/*
	  Same as on_DragStart() except the coordinates represent the ending cell of 
	the drag. If the drag terminates off the playing board, this will be called with
	the initial coordinates of the drag.
	*/
	
	//by convention, this should return a boolean value indicating if the drag was accepted or not.
	return false;
}


void Chess::on_NewGame()
{
	//g_debug("Chess::on_NewGame");
	/*
	Called when someone selects 'New' from the toolbar, 'Game' menu, or presses 'Ctrl-N'.
	*/

	delete game;
	game = NULL;
	clearBoard();
	game = new Game();
	placePieces();
	gui->SetStatusBar("White's Turn");
	savefile.clear();
}

void Chess::on_SaveGame()
{
	//g_debug("Chess::on_SaveGame");
	/*
	Called when someone selects 'Save' from the toolbar, 'Game' menu, or presses 'Ctrl-S'.
	*/
	if(savefile.size() ==0)
		savefile = gui->SelectSaveFile();
	
	saveGame();
}

void Chess::on_SaveGameAs()
{
	//g_debug("Chess::on_SaveGameAs");

	/*
	Called when someone selects 'Save As' from the 'Game' menu, or presses 'Shift-Ctrl-S'.
	*/
	savefile = gui->SelectSaveFile();
	saveGame();

}
void Chess::on_LoadGame()
{
	//g_debug("Chess::on_LoadGame");
	/*
	Called when someone selects 'Open' from the toolbar, 'Game' menu, or presses 'Ctrl-O'.
	*/

	std::string filename = gui->SelectLoadFile();
	string XMLdata;
	ifstream filestream;
	filestream.open(filename.c_str());
        if(!filestream)
        {
                cout<< "USAGE:Unable to open file\r\n" << endl;
        }
        else
        {	stringstream loadstream;	
		loadstream << filestream.rdbuf();
		XMLdata = loadstream.str();
		filestream.close();
		game->clearGame();

		game->parseXML(XMLdata);

		refreshBoard();
		if(game->getTurn() == white)
			gui->SetStatusBar("White's Turn");
		else gui->SetStatusBar("Black's Turn");

		game->clearValidMoves();

	}
		
}

void Chess::on_UndoMove()
{
	//g_debug("Chess::on_UndoMove");
	
	/*
	Called when someone selects 'Undo' from the toolbar, 'Game' menu, or presses 'Ctrl-Z'.
	*/
	if(game->getHistorySize()==0)
	{
		g_debug("No Moves to Undo");
	}
	else
	{
		Move lastmove = game->undoMove();
		Position now = lastmove.getNewPosition();
		Position backto = lastmove.getOldPosition();
		Piece * moving = game->getPiece(backto);
		ImageName image = getImageName(moving);
		gui->ClearPiece(now.getRow(),now.getCol());
		gui->PlacePiece(backto.getRow(),backto.getCol(),image);
		//Move lastmove = game->undoMove();
		if(lastmove.didCapture())
		{
			//g_debug("Putting captured piece back");
			Piece * captured = game->getPiece(now);
			image = getImageName(captured);
			gui->PlacePiece(now.getRow(),now.getCol(),image);
		}
		unHighlightMoves(game->getValidMoves());
		game->clearValidMoves();
	
	}
	if(game->getTurn() == white)
		gui->SetStatusBar("White's Turn");
	else gui->SetStatusBar("Black's Turn");

}


void Chess::on_QuitGame()
{
	//g_debug("Chess::on_QuitGame");
	/*It is not required to implement this function*/

	/*
		Called when someone selects 'Quit' from the toolbar, 'Game' menu, presses 'Ctrl-Q', or closes the window.<br>
	on_QuitGame() does not need to be implemented to fulfill the requirements of the project, but is available for your
	use.
	*/

	//delete game;
}





/**********You Do Not Need To Touch These Functions***********************************/


void Chess::run(Gtk::Main & app)
{
	app.run(*gui);
}



void log_handler(const gchar *log_domain, GLogLevelFlags log_level, const gchar *message, gpointer user_data)
{
        ///@todo Provide more info
	std::string output= std::string(message?message:"");
	bool fatal=false;
	
	if(log_level & G_LOG_FLAG_FATAL) fatal=true;
	
	//if a level is set in the LOG_LEVEL_HIDE_MASK it will fall through to the
	//default case and so will not be printed
	int level = log_level & (~LOG_LEVEL_HIDE_MASK & G_LOG_LEVEL_MASK);
					
	switch(level)
	{
		case G_LOG_LEVEL_DEBUG:
				output = std::string("DEBUG::")+output;
			break;
		case G_LOG_LEVEL_ERROR:
			output = std::string("ERROR::")+output;
			break;
		case G_LOG_LEVEL_CRITICAL:
			output = std::string("CRITICAL::")+output;
			break;
		case G_LOG_LEVEL_WARNING:
			output = std::string("WARNING::")+output;
			break;
		case G_LOG_LEVEL_MESSAGE:
			output = std::string("MESSAGE::")+output;
			break;
		case G_LOG_LEVEL_INFO:
			output = std::string("INFO::")+output;
			break;
		default:
			output="";
	}
	
	if(fatal)
	{
		std::cerr<<"FATAL ERROR::TERMINATING::"<<output<<std::endl;
		exit(1);
	}
	else if(output != "")
	{
		if(user_data)
		{
			//user data must be ChessGui!!!
			static_cast<ChessGui *>(user_data)->WriteMessageArea(output+"\n");
		}
		else
		{
			std::cerr<<output<<std::endl;
		}
	}
	else {}
	return;
}
/**************************************************************************/

void Chess::placePieces()
{
	/*Piece ** pieces = 0;
	//Piece * pieces[32];
	game->getPieces(pieces);
	
	//gui->PlacePiece(0,0,B_ROOK);

	for(int i=0; i<32; i++)
	{
		//cout << "Placing Piece: " << i << endl;
		Position here = pieces[i]->getCurrentPlace();
		int row = here.getRow();
		//cout << "Row: " << row << endl;
		int col = here.getCol();
		//cout << "Col: " << col << endl;
		colors color = pieces[i]->getColor();
		PieceType type = pieces[i]->getType();
		//cout << "Color/Type: " << color << "/" <<type<< endl;
		//cout << color << " " << type<<endl;

		ImageName image = getImageName(pieces[i]);
		gui->PlacePiece(row,col,image);
		
				

	}
	*/
	
	for(int row =0; row<8; row++)
	{
		for(int col =0; col<8; col++)
		{
			Position here =Position(row, col);
			if(game->hasPiece(here))
			{
				ImageName image = getImageName(game->getPiece(here));
				gui->PlacePiece(row,col,image);
			}
		
		}
	}
}

ImageName Chess::getImageName(Piece * piece)
{
	ImageName image;
	colors color = piece->getColor();
	PieceType type = piece->getType();
	if(color == white)
	{
		image = whitePieces(type);
	}
	else//color is black
	{
		image = blackPieces(type);
	}
	
	return image;

}

ImageName Chess::whitePieces(PieceType type)
{
	ImageName image;

	switch(type)
	{
		case pawn:
			image = W_PAWN;
			break;
		case knight:
			image = W_KNIGHT;
			break;
		case bishop:
			image = W_BISHOP;
			break;
		case rook:
			image = W_ROOK;
			break;
		case queen:
			image = W_QUEEN;
			break;
		case king:
			image = W_KING;
			break;

	}
	return image;
}

ImageName Chess::blackPieces(PieceType type)
{
	ImageName image;

	switch(type)
	{
		case pawn:
			image = B_PAWN;
			break;
		case knight:
			image = B_KNIGHT;
			break;
		case bishop:
			image = B_BISHOP;
			break;
		case rook:
			image = B_ROOK;
			break;
		case queen:
			image = B_QUEEN;
			break;
		case king:
			image = B_KING;
			break;
	}
	return image;

}

void Chess::highlightMoves(set<Move> moves)
{
	set<Move>::iterator moveiter;
	for(moveiter = moves.begin(); moveiter!=moves.end(); moveiter++)
	{
		Move tempmove = *moveiter;
		Position temp = tempmove.getNewPosition();
		gui->HighlightSquare(temp.getRow(),temp.getCol(),RED_SQUARE);
	}

}

void Chess::unHighlightMoves(set<Move> moves)
{
	set<Move>::iterator moveiter;
	for(moveiter = moves.begin(); moveiter!=moves.end(); moveiter++)
	{
		Move tempmove = *moveiter;
		Position temp = tempmove.getNewPosition();
		gui->UnHighlightSquare(temp.getRow(),temp.getCol());
	}

}

void Chess::clearBoard()
{
	for(int row=0; row<8; row++)
	{
		for(int col=0; col<8; col++)
		{
			gui->ClearPiece(row,col);
			gui->UnHighlightSquare(row,col);

		}
	}
}

string Chess:: XMLOut()
{
	stringstream outputstream;
	string xmlout;
	outputstream << "<chessgame>" << endl;
	outputstream << game->getBoardXML() << endl;
	outputstream << game->getMoveXML() << endl;
	outputstream << "</chessgame>" << endl;

	xmlout = outputstream.str();
	
	return xmlout;

}		

void Chess::saveGame()
{
	ofstream outputstream;
	outputstream.open(savefile.c_str());
	outputstream << XMLOut() << endl;;
	outputstream.close();

}

void Chess::refreshBoard()
{
	clearBoard();
	placePieces();
	
	
}

