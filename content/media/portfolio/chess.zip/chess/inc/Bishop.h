#ifndef CHESSBishop_H
#define CHESSBishop_H

#include <set>
#include "Move.h"
#include "Piece.h"
#include "Enums.h"
#include "Position.h"


class Bishop: public Piece
{

	public:
	
	Bishop(colors testcolor, Position testposition);

	
	virtual set<Move> getMoves(Board &currentboard);
	/* 	find the valid moves for the piece
		parameter: none
		returns: set of valid Move objects
	*/

	static bool Test(ostream &os);

};


#endif



