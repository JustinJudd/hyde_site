#ifndef CHESSGame_H
#define CHESSGame_H

#include "Enums.h"
#include "Piece.h"
#include "Pieces.h"
#include "Board.h"
#include "Position.h"
#include "Move.h"
#include <set>
#include <string>
#include <list>
#include "XMLParser.h"
#include <sstream>
#include <stdio.h>

using namespace std;



class Game
{

	public:

	Game();
	/* 	Initializes Game object
		parameter: none
		returns: none
	*/
	~Game();

	
	void clearGame();
	/* 	Clears all the objects in the game
		parameter: none
		returns: none
	*/

	
	void createPieces();
	/* 	creates all the pieces for the start of the game
		parameter: none
		returns: none
	*/

	void getInitPositions(Position initial[]);
	void getInitTypes(PieceType types[]);
/*	void getPieces(Piece ** returnpieces)
	{
		returnpieces = pieces;
	}
*/

	void setTurn(colors setcolor);
	/* 	sets whose turn it is
		parameter: color of whose turn it is
		returns: none
	*/

	void switchTurn();//Switches turn at end of move

	colors getTurn();
	/* 	Find out whose turn it is
		parameter: none
		returns: color of whose turn it is
	*/

	void movePiece(Piece * piece, Position place, Move move);
	/* 	Moves a piece
		parameter: Pointer to piece to be moved
		returns: none
	*/
	
	Move undoMove();
	/* 	Undo last move
		parameter: none
		returns: none
	*/

	void saveGame(string filename);
	/* 	Save Game
		parameter: filename of where to save file
		returns: none
	*/

	void loadGame(string filename);
	/* 	Load Game
		parameter: filename of where to find file to load
		returns: none
	*/

	void getPieces(Piece ** &returnpieces);

	set<Move> getValidMoves();
	set<Move> getValidMoves(set<Move> moves);
	void clearValidMoves();
	bool getMoves(Position chosen);
	//Board * getBoard();
	Board * getBoard();
	bool hasPiece(Position position);
	Piece * getPiece(Position position);
	Piece * getChosenPiece();
	bool isValidMove(Position chosen, Position before);
	Piece * createPiece(colors newcolor, PieceType newtype, Position starting);
	int getHistorySize();
	string getBoardXML();
	string getMoveXML();
	string pieceXML(PieceType ptype, colors pcolor, Position ppos);
	string typeToText(PieceType convert);
	string colorToText(colors convert);
	void parseXML(string data);
	bool checkForCheck(colors piececolor);
	bool checkForCheck(colors piececolor, Board board);
	bool wouldCapture(Position kinghere, set<Move> moves);
	Position findKing(colors color);
	Position findKing(colors color, Board board);
	bool getCheckStatus(colors color);
	void removeMoves(set<Move> invalid, set<Move> &moves);
	bool colorCanMove(colors color);
	void setGameStatus(colors color);
	bool inCheckMate();
	bool inStaleMate();
	bool getCheckStatus();



	private:
	colors turncolor; //keeps track of whose turn it is
	Piece * pieces[32];
	//Board * gameboard; //the chessboard
	Board gameboard;
	list<Move> MoveHistory; //Keeps track of all of the moves in a game
	set<Move> ValidMoves;
	//set<Move> validmoves;
	XMLParser * parser; //used to parse game information to load game
	Piece * chosenpiece;
	bool whitecheck;
	bool whitecheckmate;
	bool whitestalemate;
	bool blackcheck;
	bool blackcheckmate;
	bool blackstalemate;

	
};

#endif


	
