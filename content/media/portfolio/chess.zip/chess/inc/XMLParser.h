#ifndef CHESS_XMLParser_H
#define CHESS_XMLParser_H

#include <string>
#include "Board.h"
#include <list>
#include "Move.h"
#include <boost/regex.hpp>
#include <boost/bind.hpp>
#include "Pieces.h"

using namespace std;

class XMLParser
{

	public:
	
	XMLParser(string input);
	/* 	Initializes XMLParser object
		parameter: none
		returns: none
	*/
	
	Board getBoard();
	/* 	Forms a Board object from the XML data
		parameter: none
		returns: Board object wwith pieces in position
	*/

	list<Move> getHistory();
	/* 	takes the history data from the xml file 
		and puts it into Move objects and puts those into a list
		parameter: none
		returns: list of move objects(MoveHistory)
	*/

	string regexData(string data, boost::regex eTag);
	void createBoard(string boarddata);
	bool createPieces(const boost::match_results<std::string::const_iterator>& place);
	Piece * createPiece(string color, string type, Position starting);
	colors getColorValue(string colorcheck);
	PieceType getTypeValue(string newtype);
	void createHistory(string data);
	bool createMoves(const boost::match_results<std::string::const_iterator>& place);


	private:

	Board storedboard;
	list<Move> storedhistory;
	int movecount;
	//Piece * pieces[32];
	bool creatingboard;
	Move * currentmove;
	bool firstposition;
	bool captured;

};

#endif
