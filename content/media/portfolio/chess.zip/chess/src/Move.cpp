#include "Move.h"

Move::Move(PieceType newtype, colors newcolor, Position oldplace, Position newplace) :
  	   moved(newtype), piececolor(newcolor), firstposition(oldplace), secondposition(newplace)
{
	captured = false;
}

Move::Move()
{
	
	captured = false;
}

Move::Move(const Move &copy)
{
	moved = copy.moved;
	piececolor = copy.piececolor;
	firstposition = copy.firstposition;
	secondposition = copy.secondposition;
	capturedtype = copy.capturedtype;
	captured = copy.captured;
	capturedcolor = copy.capturedcolor;
}

bool Move::operator<(const Move& checkmove) const
{
	return secondposition.getValue() < checkmove.secondposition.getValue();
}
/*inline bool Move::operator>( Move& checkmove) 
{
	return secondposition.getValue() > checkmove.secondposition.getValue();
}
inline bool Move::operator==( Move& checkmove) 
{
	return secondposition.getValue() == checkmove.secondposition.getValue();	
}
*/
/*inline bool Move::operator<(Move& amove, Move& bmove)
{
	return amove.secondposition.getValue() == bmove.secondposition.getValue()
}
*/


	
void Move::setPieceType(PieceType newpiecetype)
{
	moved = newpiecetype;

}
void Move::setColor(colors newcolor)
{
	piececolor = newcolor;
}

void Move::setOldPosition(Position oldposition)
{
	firstposition = oldposition;
}

void Move::setNewPosition(Position newposition)
{
	secondposition = newposition;
}

void Move::setCaptured(PieceType capturedpiece)
{
	capturedtype = capturedpiece;
	captured = true;
	if(piececolor == white)
		capturedcolor = black;
	else capturedcolor = white;
}

bool Move::didCapture()
{
	return captured;
}

PieceType Move::getPieceType()
{
	return moved;
}

colors Move::getColor()
{
	return piececolor;
}
	
Position Move::getOldPosition()
{
	return firstposition;
}

Position Move::getNewPosition()
{
	return secondposition;
}

PieceType Move::getCapturedPiece()
{
	return capturedtype;
}

colors Move::getCapturedColor()
{
	return capturedcolor;
}




