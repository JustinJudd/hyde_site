#ifndef CHESSPosition_H
#define CHESSPosition_H

class Position
{
 	public:
	
	/* 	Initializ Position objec
		parameter: row, colun
		returns: none
	*/
	Position(int newrow, int newcol);

	Position();

	bool operator<(const Position& checkposition)const;
	bool operator>(const Position& checkposition)const;
	bool operator==(const Position& checkposition)const;
	


	/* 	get the row of the position
		parameter: none
		returns: the row
	*/
	int getRow();
	/* 	get the column of the position
		parameter: none
		returns: the column
	*/
	int getCol();

	int getValue() const;

	private:

	int row; //row of the position
	int col; //column of the position
};

#endif



