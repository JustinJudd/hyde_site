#ifndef CHESSKing_H
#define CHESSKing_H

#include <set>
#include "Move.h"
#include "Piece.h"
#include "Enums.h"


class King:public Piece
{

	public:

	King(colors newcolor, Position newposition);

	
	virtual set<Move> getMoves(Board &currentboard);
	/* 	find the valid moves for the piece
		parameter: none
		returns: set of valid Move objects
	*/
	
	static bool Test(ostream &os);
	
};


#endif


	
