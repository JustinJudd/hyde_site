#include "Knight.h"
#include "Pieces.h"

Knight::Knight(colors newcolor, Position newposition): Piece(newcolor, newposition)
{
	type = knight;
}


set<Move> Knight::getMoves(Board &currentboard)
{
	int onrow = current.getRow();
	int oncol = current.getCol();

	set<Move> moves;
	Position positions[8];
	positions[0] = Position(onrow+2,oncol+1);
	positions[1] = Position(onrow+1,oncol+2);
	positions[2] = Position(onrow-1,oncol+2);
	positions[3] = Position(onrow-2,oncol+1);
	positions[4] = Position(onrow-2,oncol-1);
	positions[5] = Position(onrow-1,oncol-2);
	positions[6] = Position(onrow+1,oncol-2);
	positions[7] = Position(onrow+2,oncol-1);

	
	for (int i=0;i<8; i++)
	{
		int row = positions[i].getRow();
		int col = positions[i].getCol();

		if(row>=0 && row<8 && col>=0 && col<8)
		{
		
			if(currentboard.getSquare(positions[i])->containsPiece())
			{
				Piece * barrier = currentboard.getSquare(positions[i])->getPiece();
				if(barrier->getColor() != getColor())
				{
					moves.insert(createMove(positions[i], barrier->getType()));
					//moves.insert(createMove(positions[i]));
	
				}
			}
			else
			{
				moves.insert(createMove(positions[i]));
			}
	
	
		}
		

	}


	return moves;
}

bool Knight::Test(ostream &os)
{
	//Knight will be white, will be either at (0,0) or (3,3)
	bool validmoves = false;

	Board board = Board();
	Position start = Position(0,0);
	Piece * testknight = new Knight(white, start);

	Square * place = board.getSquare(start);
	
	Position other = Position(4,5);
	Piece * pawnpiece = new Pawn(white, other);
	Piece * rookpiece = new Rook(black, other);

	Square * otherplace = board.getSquare(other);

	place->setPiece(testknight);

	set<Move> testmoves = testknight->getMoves(board);

	if(testmoves.size() ==2)
	{
		set<Move>::iterator iter;
		int count =0;
		for(iter=testmoves.begin(); iter!=testmoves.end(); iter++)
		{
			Move testmove = *iter;
			Position newplace = testmove.getNewPosition();
			if(count==0 && newplace.getRow()!=1 && newplace.getCol()!=2 )
				validmoves=true;
			if(count==1 && newplace.getRow()!=2 && newplace.getCol()!=1 && validmoves)
				validmoves = true;
			else validmoves = false;
	
			count++;
		
		}
	}
	delete testknight;
	start = Position(3,3);
	testknight = new Knight(white, start);

	board = Board();
	place = board.getSquare(start);
	place->setPiece(testknight);
	otherplace = board.getSquare(other);
	otherplace->setPiece(pawnpiece);

	testmoves = testknight->getMoves(board);

	if(testmoves.size() ==7)
	{
		validmoves = true;
		set<Move>::iterator iter;
		for(iter=testmoves.begin(); iter!=testmoves.end(); iter++)
		{
			Move testmove = *iter;
			Position newplace = testmove.getNewPosition();
			if(newplace.getRow()==4 && newplace.getCol()==5)
			{
				validmoves = false;
				os << "Invalid Move Returned, Knight Case 2 Failed" << endl;
			}
	
	
		}
	}
	
	otherplace->setPiece(rookpiece);

	testmoves = testknight->getMoves(board);
	if(testmoves.size() ==8 && validmoves)
	{
		validmoves = true;

	}
	else
	{
		if(validmoves)
			os << "Knight Case 3 failed" << endl;
		validmoves = false;
		
	}
	

	return validmoves;
}

/*Move Knight::createMove(Position movehere, PieceType capturedtype)
{
	Move newmove = Move(getType(),getColor(), getCurrentPlace(), movehere);
	newmove.setCaptured(capturedtype);
	return newmove;
}

Move Knight::createMove(Position movehere)
{
	Move newmove = Move(getType(),getColor(), getCurrentPlace(), movehere);
	return newmove;
}
*/
