#ifndef CHESSMove_H
#define CHESSMove_H

#include "Position.h"
#include "Enums.h"

class Move
{
	public:
	
	Move(PieceType newtype, colors newcolor, Position oldplace, Position newplace);
	/* 	initialize Move
		parameters: type of piece being moved, 
		color of piece being moved, 
		the position it is moving from, and position it is moving to
		returns: nothing
	*/

	Move();

	Move(const Move &copymove);
	
	bool operator<(const Move& checkmove) const;
	//inline bool operator>( Move& checkmove);
	//inline bool operator==( Move& checkmove);
	//inline bool operator<(Move& amove, Move& bmove);


	void setPieceType(PieceType newpiecetype);
	/* 	set the type of the piece that is moving
		parameter: the type of piece that is moving
		returns: nothing
	*/
	void setColor(colors newcolor);
	/* 	set the color of the piece that is moving
		parameter: the color of piece that is moving
		returns: nothing
	*/
	void setOldPosition(Position oldposition);
	/* 	set the starting position of the piece that is moving
		parameter: the starting position of piece that is moving
		returns: nothing
	*/
	void setNewPosition(Position newposition);
	/* 	set the ending position of the piece that is moving
		parameter: the ending position of piece that is moving
		returns: nothing
	*/
	void setCaptured(PieceType capturedpiece);
	/* 	set the type of the piece that was captured
		parameter: the type of piece that was captured
		returns: nothing
	*/
	bool didCapture();
	/* 	check if a piece was captured in the move
		parameter: none
		returns: true if a piece was captured, false if not
	*/

	PieceType getPieceType();
	/* 	get the type of piece moved
		parameter: none
		returns: type of piece moved
	*/
	colors getColor();
	/* 	get the color of piece moved
		parameter: none
		returns: color of piece moved
	*/
	Position getOldPosition();
	/* 	get the first position of piece moved
		parameter: none
		returns: first position of piece moved
	*/
	Position getNewPosition();
	/* 	get the second position of piece moved
		parameter: none
		returns: second position of piece moved
	*/
	PieceType getCapturedPiece();
	/* 	get the type of piece captured
		parameter: none
		returns: type of piece captured
	*/
	colors getCapturedColor();
	/* 	get the color of piece captured
		parameter: none
		returns: color of piece captured
	*/


	private:

	PieceType moved; //Type of the piece that was moved
	colors piececolor; //color of the piece that was moved
	Position firstposition; //The first position of the moved piece
	Position secondposition; //the second position of the moved piece
	PieceType capturedtype; //the type of the piece that was captured
	bool captured; //boolean if piece was captured
	colors capturedcolor; //color of the piece that was captured


};

#endif



