#include "XMLParser.h"
#include <boost/regex.hpp>
#include <boost/bind.hpp>

XMLParser::XMLParser(string input)
{
	boost::regex eColor, eType, eCol, eRow, eGame, eBoard, eHistory, eMoves, ePiece;
	//piececount = 0;
	creatingboard = false;
	string gamedata, boarddata, historydata, movedata, piecedata;
	
	const char* colortag = "color[\"\']?([^\"\'>]*)[\"\']?";
	const char* typetag = "type[\"\']?([^\"\'>]*)[\"\']?";
	const char* coltag = "col[\"\']?([^\"\'>]*)[\"\']?";
	const char* rowtag = "row[\"\']?([^\"\'>]*)[\"\']?";
	const char* gametag = "<chessgame>(.*?)</chessgame>";
	const char* boardtag = "<board>(.*?)</board>";
	const char* historytag = "<history>(.*?)</history>";
	const char* movetag = "<move>(.*?)</move>";
	const char* piecetag = "<piece(.*?)/>";



	eColor.assign(colortag,boost::regex_constants::icase);
	eType.assign(typetag,boost::regex_constants::icase);
	eCol.assign(coltag,boost::regex_constants::icase);
	eRow.assign(rowtag,boost::regex_constants::icase);
	eGame.assign(gametag, boost::regex_constants::icase);
	eBoard.assign(boardtag, boost::regex_constants::icase);
	eHistory.assign(historytag,boost::regex_constants::icase);
	eMoves.assign(movetag, boost::regex_constants::icase);
	ePiece.assign(piecetag, boost::regex_constants::icase);


	gamedata = regexData(input, eGame);
	if(gamedata.size()!=0)
	{
		boarddata = regexData(gamedata, eBoard);
		createBoard(boarddata);

		historydata = regexData(gamedata, eHistory);
			createHistory(historydata);
		
	}

	
		


}
/*XMLParser::~XMLParser()
{
	//delete currentmove;
}
*/
string XMLParser::regexData(string data, boost::regex eTag)
{
	string returndata;
	boost::smatch match;
	regex_search(data, match, eTag); 
	if(match[0].matched)
	{
		returndata = match[1];
		
	}
	
	return returndata;
}

void XMLParser::createBoard(string boarddata)
{
	//Board newboard = Board();
	creatingboard = true;
	boost::regex ePiece;
	const char* piecetag = "<piece(.*?)/>";
	ePiece.assign(piecetag, boost::regex_constants::icase);


	

	boost::smatch match;
	boost::sregex_iterator iterator1(boarddata.begin(), boarddata.end(), ePiece);
     	boost::sregex_iterator iterator2;

	std::for_each(iterator1, iterator2, boost::bind(&XMLParser::createPieces, this, _1));

	creatingboard = false;
}

bool XMLParser::createPieces(const boost::match_results<std::string::const_iterator>& place)
{
	boost::regex eColor, eType, eCol, eRow;
	string piecedata = place[1];
	string type, color;
	int row, col;
	const char* colortag = "color[\\b]?[\\n]?[\\t]?=[\\b]?[\\n]?[\\t]?[\"\']?([^\"\'>]*)[\"\']?";
	const char* typetag = "type[\\b]?[\\n]?[\\t]?=[\\b]?[\\n]?[\\t]?[\"\']?([^\"\'>]*)[\"\']?";
	const char* coltag = "column[\\b]?[\\n]?[\\t]?=[\\b]?[\\n]?[\\t]?[\"\']?([^\"\'>]*)[\"\']?";
	const char* rowtag = "row[\\b]?[\\n]?[\\t]?=[\\b]?[\\n]?[\\t]?[\"\']?([^\"\'>]*)[\"\']?";
	eColor.assign(colortag,boost::regex_constants::icase);
	eType.assign(typetag,boost::regex_constants::icase);
	eCol.assign(coltag,boost::regex_constants::icase);
	eRow.assign(rowtag,boost::regex_constants::icase);

	
	color = regexData(piecedata, eColor);
	type = regexData(piecedata, eType );
	col = atoi(regexData(piecedata, eCol).c_str());
	row = atoi(regexData(piecedata, eRow).c_str());
	//cout << "PieceData:  Color: " << color << "Type: " << type << endl;


	//cout << "Row: " << regexData(piecedata, eRow) << " Col: " << regexData(piecedata, eCol) << endl;
	//cout << "Row value: " << row << " Col Value: " << col << endl;


	Position position = Position(row, col);
	//Piece * temp = createPiece(color,type, position);
	if(creatingboard)
	{	
		Piece * temp = createPiece(color,type, position);
		storedboard.getSquare(position)->setPiece(temp);
	}
	else 
	{
		PieceType temptype = getTypeValue(type);
		colors tempcolor = getColorValue(color);

		if(movecount == 0)
		{
			//cout << "first step of recreating move" << endl;
			//Move working = *currentmove;
			cout << "Type: " << temptype << " Color: " << tempcolor << endl;
			//working.setPieceType(temptype);
			//working.setOldPosition(position);
			//working.setColor(tempcolor);
			currentmove->setPieceType(temptype);
			currentmove->setOldPosition(position);
			currentmove->setColor(tempcolor);
			
		}
		if(movecount == 1)
		{
			//cout << "second step of recreating move" << endl;
			//Move working = *currentmove;
			//working.setNewPosition(position);
			currentmove->setNewPosition(position);
		}
		if(movecount ==2 )
		{
			//cout << "capturing step of recreating move" << endl;
			//Move working = *currentmove;
			//working.setCaptured(getTypeValue(type));	
			currentmove->setCaptured(temptype);
		}
		
		movecount++;
	}
	
	
	return true;
}


Piece * XMLParser::createPiece(string color, string type, Position starting)
{
	Piece * newpiece;
	colors newcolor = getColorValue(color);
	PieceType newtype = getTypeValue(type);
	if(newtype==pawn)
		newpiece = new Pawn(newcolor, starting);
	if(newtype==knight)
		newpiece = new Knight(newcolor, starting );
	if(newtype==bishop)
		newpiece = new Bishop(newcolor, starting );
	if(newtype==rook)
		newpiece = new Rook(newcolor, starting);
	if(newtype==queen)
		newpiece = new Queen(newcolor, starting );
	if(newtype==king)
		newpiece = new King(newcolor, starting);

	return newpiece;
}


colors XMLParser::getColorValue(string colorcheck)
{
	if(colorcheck == "white")
		return white;
	else return black;
}

PieceType XMLParser::getTypeValue(string newtype)
{
	if(newtype=="pawn")
		return pawn;
	if(newtype=="knight")
		return knight;
	if(newtype=="bishop")
		return bishop;
	if(newtype=="rook")
		return rook;
	if(newtype=="queen")
		return queen;
	if(newtype=="king")
		return king;

	return pawn;
}

void XMLParser::createHistory(string data)
{
	boost::regex eMove;
	const char* movetag = "<move>(.*?)</move>";
	eMove.assign(movetag, boost::regex_constants::icase);

	boost::smatch match;
	boost::sregex_iterator iterator1(data.begin(), data.end(), eMove);
     	boost::sregex_iterator iterator2;

	std::for_each(iterator1, iterator2, boost::bind(&XMLParser::createMoves, this, _1));


}

bool XMLParser::createMoves(const boost::match_results<std::string::const_iterator>& place)
{
	movecount = 0;
	Move working = Move();
	currentmove = &working;
	boost::regex ePiece;
	const char* piecetag = "<piece(.*?)/>";
	ePiece.assign(piecetag, boost::regex_constants::icase);

	string movedata = place[1];

	//cout << "MoveData: " << movedata << endl;
	

	boost::smatch match;
	boost::sregex_iterator iterator1(movedata.begin(), movedata.end(), ePiece);
     	boost::sregex_iterator iterator2;

	std::for_each(iterator1, iterator2, boost::bind(&XMLParser::createPieces, this, _1));
	


	storedhistory.push_back(working);
	currentmove = NULL;

	return true;
}

Board XMLParser::getBoard()
{
	return storedboard;

}

list<Move> XMLParser::getHistory()
{
	return storedhistory;
}
