#ifndef CHESSSquare_H
#define CHESSSquare_H

//#include "Piece.h"
//#include "Pieces.h"
class Piece;

class Square
{
	public:

	Square();

	Square(Piece *newpiece);
	
	bool containsPiece();

	void setPiece(Piece * newpiece);

	
	Piece * getPiece();
	
	void removePiece();
	
	private:

	bool havePiece; 
	Piece * piece; 


};

#endif




