#include "Pawn.h"
#include "Pieces.h"

Pawn::Pawn(colors newcolor, Position newposition): Piece(newcolor, newposition)
{
	type = pawn;
}

set<Move> Pawn::getMoves(Board &currentboard)
{
	set<Move> moves;

	if(color==black)
	{
		moves = blackPawn(currentboard);
	}
	else moves = whitePawn(currentboard);
	
	
	return moves;
}

set<Move> Pawn::blackPawn(Board &currentboard)
{
	int checkrow;
	int checkcol = current.getCol();

	set<Move> moves;
	checkrow=current.getRow()+1;
	Position first =Position(checkrow,checkcol);
	if(!currentboard.getSquare(first)->containsPiece())
	{
		Position second =Position(checkrow+1,checkcol);
		moves.insert(createMove(first));

		if(!movedYet() && !currentboard.getSquare(second)->containsPiece())
		//can move two spaces if first move
		{
			moves.insert(createMove(second));
		}

	}
			
	Position captureleft = Position(checkrow,checkcol-1);
	Position captureright = Position(checkrow, checkcol+1);
	if(currentboard.getSquare(captureleft)->containsPiece())
	{
		Piece * barrier = currentboard.getSquare(captureleft)->getPiece();
		if(barrier->getColor() != getColor())
		{
			moves.insert(createMove(captureleft, barrier->getType()));
		}
	}
	if(currentboard.getSquare(captureright)->containsPiece())
	{
		Piece * barrier = currentboard.getSquare(captureright)->getPiece();
		if(barrier->getColor() != getColor())
		{
			moves.insert(createMove(captureright, barrier->getType()));
		}

	}

	return moves;

}

set<Move> Pawn::whitePawn(Board &currentboard)
{
	int checkrow;
	int checkcol = current.getCol();

	set<Move> moves;
	checkrow=current.getRow()-1;

	Position first =Position(checkrow,checkcol);
	if(!currentboard.getSquare(first)->containsPiece())
	{
		Position second =Position(checkrow-1,checkcol);
		moves.insert(createMove(first));
		if(!movedYet() && !currentboard.getSquare(second)->containsPiece())
		//can move two spaces if first move
		{
			moves.insert(createMove(second));
				
		}

	}
			
	Position captureleft = Position(checkrow,checkcol-1);
	Position captureright = Position(checkrow, checkcol+1);
	if(currentboard.getSquare(captureleft)->containsPiece())
	{
		Piece * barrier = currentboard.getSquare(captureleft)->getPiece();
		if(barrier->getColor() != getColor())
		{
			moves.insert(createMove(captureleft, barrier->getType()));
		}
	}
	if(currentboard.getSquare(captureright)->containsPiece())
	{
		Piece * barrier = currentboard.getSquare(captureright)->getPiece();
		if(barrier->getColor() != getColor())
		{
			moves.insert(createMove(captureright, barrier->getType()));
		}

	}
	return moves;
}

bool Pawn::Test(ostream &os)
{

	//Pawn will be white, will be either at (6,0) or (3,3)
	bool validmoves = false;
	Position start = Position(6,0);
	Piece * testpawn = new Pawn(white, start);

	Board board = Board();

	Square * place = board.getSquare(start);
	place->setPiece(testpawn);
	
	Position other = Position(2,2);

	set<Move> testmoves = testpawn->getMoves(board);

	if(testmoves.size() ==2)
	{
		set<Move>::iterator iter;
		int count =0;
		for(iter=testmoves.begin(); iter!=testmoves.end(); iter++)
		{
			Move testmove = *iter;
			Position newplace = testmove.getNewPosition();
			//cout << "Place " << newplace.getRow() << "," << newplace.getCol() << endl;
			//cout << "count: " << count << endl;
			if(count==0)
			{
				if(newplace.getRow()==4 && newplace.getCol()==0 )
				{
					validmoves=true;
				}
				else
				{
					validmoves = false;
					os << "First Place incorrect" << endl;
				}
			}
			if(count==1)
			{
				if(newplace.getRow()==5 && newplace.getCol()==0 && validmoves)
					validmoves = true;
				else 
				{
					validmoves = false;
					os << "Second Place incorrect" << endl;

				}
			}	
			
	
			count++;
		
		}
	}
	else os << "Pawn Case 1 Failed" << endl;

	delete testpawn;
	start = Position(3,3);
	testpawn = new Pawn(white, start); 
	//Position other = Position(4,4);
	Piece * pawnpiece = new Pawn(white, other);
	//Piece * rookpiece = new Rook(black, other);
	board = Board();
	Square * otherplace = board.getSquare(other);

	place->setPiece(testpawn);
	otherplace->setPiece(pawnpiece);

	testmoves = testpawn->getMoves(board);

	

	if(testmoves.size() ==1 && validmoves)
	{
		//validmoves = true;
		set<Move>::iterator iter;
		for(iter=testmoves.begin(); iter!=testmoves.end(); iter++)
		{
			Move testmove = *iter;
			Position newplace = testmove.getNewPosition();
			if(newplace.getRow()==4 && newplace.getCol()==4)
			{
				validmoves = false;
				os << "Invalid Move Retuned" << endl;
			}
			
	
	
		}
	}
	else os << "Pawn Case 2 Failed" << endl;

	
	Piece * rookpiece = new Rook(black, other);
	otherplace->setPiece(rookpiece);
	testmoves = testpawn->getMoves(board);

	//cout << testmoves.size() << endl;

	if(testmoves.size() ==2 && validmoves)
	{
		validmoves = true;

	}
	else 
	{	if(validmoves)
			os << "Pawn Case 3 failed" << endl;
		validmoves = false;
	}

		
	return validmoves;

}



