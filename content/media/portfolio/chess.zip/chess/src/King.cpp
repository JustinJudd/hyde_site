#include "King.h"
#include "Pieces.h"

King::King(colors newcolor, Position newposition): Piece(newcolor, newposition)
{
	type = king;
}


set<Move> King::getMoves(Board &currentboard)
{
	int onrow =current.getRow();
	int oncol = current.getCol();

	set<Move> moves;
	Position positions[8];
	positions[0] = Position(onrow-1,oncol+1);
	positions[1] = Position(onrow,oncol+1);
	positions[2] = Position(onrow+1,oncol+1);
	positions[3] = Position(onrow-1,oncol);
	positions[4] = Position(onrow+1,oncol);
	positions[5] = Position(onrow-1,oncol-1);
	positions[6] = Position(onrow,oncol-1);
	positions[7] = Position(onrow+1,oncol-1);

	
	for (int i=0;i<8; i++)
	{
		int row = positions[i].getRow();
		int col = positions[i].getCol();

		if(row>=0 && row<8 && col>=0 && col<8)
		{
		
			if(currentboard.getSquare(positions[i])->containsPiece())
			{
				Piece * barrier = currentboard.getSquare(positions[i])->getPiece();
				if(barrier->getColor() != getColor())
				{
					moves.insert(createMove(positions[i], barrier->getType()));
					//moves.insert(createMove(positions[i]));
	
				}
			}
			else
			{
				moves.insert(createMove(positions[i]));
			}
	
	
		}
		

	}
		

	


	return moves;

}

bool King::Test(ostream &os)
{

	//King will be white, will be either at (0,0) or (3,3)
	bool validmoves = false;
	Position start = Position(0,0);
	Piece * testking = new King(white, start);
	Board board = Board();

	Square * place = board.getSquare(start);
	
	
	Square * otherplace;

	place->setPiece(testking);

	set<Move> testmoves = testking->getMoves(board);

	if(testmoves.size() ==3)
	{
		set<Move>::iterator iter;
		int count =0;
		for(iter=testmoves.begin(); iter!=testmoves.end(); iter++)
		{
			Move testmove = *iter;
			Position newplace = testmove.getNewPosition();
			//cout << "Place " << newplace.getRow() << "," << newplace.getCol() << endl;
			//cout << "count: " << count << endl;
			if(count==0)
			{
				if(newplace.getRow()==0 && newplace.getCol()==1 )
					validmoves=true;
				else
				{
					os << "King Corner Move incorrect" << endl;
				}
			}
			if(count==1)
			{
				if(newplace.getRow()==1 && newplace.getCol()==0 && validmoves)
					validmoves = true;
				else
				{
					os << "King Corner Move incorrect" << endl;
				}
			}

			if(count==2)
			{
				if(newplace.getRow()==1 && newplace.getCol()==1 && validmoves)
					validmoves = true;
				else
				{
					os << "King Corner Move incorrect" << endl;
				}
			}

			
	
			count++;
		
		}
	}
	else os<< "King Test Case 1 Failed" << endl;
	delete testking;
	start = Position(3,3);
	testking = new King(white, start);
	board = Board();
	Position other = Position(4,3);
	Piece * pawnpiece = new Pawn(white, other);
	Piece * rookpiece = new Rook(black, other);
	place = board.getSquare(start);
	
	
	otherplace = board.getSquare(other);

	place->setPiece(testking);


	otherplace->setPiece(pawnpiece);

	testmoves = testking->getMoves(board);

	if(testmoves.size() ==7 && validmoves)
	{
		validmoves = true;
		set<Move>::iterator iter;
		for(iter=testmoves.begin(); iter!=testmoves.end(); iter++)
		{
			Move testmove = *iter;
			Position newplace = testmove.getNewPosition();
			if(newplace.getRow()==4 && newplace.getCol()==3)
			{
				validmoves = false;
				os << "Invalid Move returned" << endl;
			}
	
	
		}
	}
	else 
	{
		if(validmoves)
			os << "King Test Case 2 failed" << endl;
		validmoves = false;

	}
	otherplace->setPiece(rookpiece);

	testmoves = testking->getMoves(board);
	if(testmoves.size() ==8 && validmoves)
	{
		validmoves = true;

	}
	else 
	{
		if(validmoves)
			os << "King Test Case 3 failed" << endl;
		validmoves = false;

	}
	
	return validmoves;

}


/*Move King::createMove(Position movehere, PieceType capturedtype)
{
	Move newmove = Move(getType(),getColor(), getCurrentPlace, movehere);
	if(capturedType != NULL)
		newmove.setCaptured(capturedtype);
	return newmove;
}
*/
