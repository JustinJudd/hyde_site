#ifndef CHESSRook_H
#define CHESSRook_H

#include <set>
#include "Move.h"
#include "Piece.h"
#include "Enums.h"


class Rook : public Piece
{

	public:

	Rook(colors pawncolor, Position first);
	
	virtual set<Move> getMoves(Board &currentboard);
	/* 	find the valid moves for the piece
		parameter: none
		returns: set of valid Move objects
	*/

	static bool Test(ostream &os);
	
};


#endif



