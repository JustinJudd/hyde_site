#ifndef CHESSPawn_H
#define CHESSPawn_H


#include <set>
#include "Move.h"
#include "Piece.h"
#include "Enums.h"

using namespace std;

class Pawn : public Piece
{

	public:

	Pawn(colors newcolor, Position newposition);
	
	/* 	find the valid moves for the piece
		parameter: none
		returns: set of valid Move objects
	*/
	virtual set<Move> getMoves(Board &currentboard);

	set<Move> blackPawn(Board &currentboard);
	set<Move> whitePawn(Board &currentboard);

	static bool Test(ostream &os);


};


#endif



