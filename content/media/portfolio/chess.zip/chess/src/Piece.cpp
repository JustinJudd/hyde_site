#include "Piece.h"
#include <stdio.h>
#include "Pieces.h"

using namespace std;

/*Piece::Piece(colors newcolor, Position newposition, PieceType newtype):
	color(newcolor), current(newposition), type(newtype)
{
	cout<< "Creating Piece" << endl;

}
*/
Piece::Piece(colors newcolor, Position newposition)
{
	color = newcolor;
	current = newposition;
	moved = false;
}

colors Piece::getColor()
{	
	return color;
}

PieceType Piece::getType()
{
	return type;
}

Position Piece::getCurrentPlace()
{
	return current;
}

Position Piece::getPreviousPlace()
{
	return previous;
}

void Piece::setCurrentPlace(Position place)
{
	current = place;
}

bool Piece::movedYet()
{
	int checkrow;
	if(color==white)
		checkrow=6;
	else checkrow =1;
	if(current.getRow()==checkrow)
		moved=false;
	else moved=true;
	
	return moved;
}

Move Piece::createMove(Position movehere, PieceType capturedtype)
{
	Move newmove = Move(getType(),getColor(), getCurrentPlace(), movehere);
	newmove.setCaptured(capturedtype);
	return newmove;
}

Move Piece::createMove(Position movehere)
{
	Move newmove = Move(getType(),getColor(), getCurrentPlace(), movehere);
	return newmove;
}




set<Position> Piece::getLinearPositions(Board &board)
{
	//int checkrow = current.getRow();
	//int checkcol = current.getCol();
	set<Position> positions, first, second;

	first = LinearUpnDown(board);
	second = LinearLeftnRight(board);
	positions = mergePositions(first,second);
	
	return positions;

}

set<Position> Piece::LinearUpnDown(Board &board)
{
	int checkrow = current.getRow();
	int checkcol = current.getCol();
	set<Position> positions;

	//check spaces below in column
	for(int i=checkrow-1; i>=0; i--)
	{
		Position checkhere = Position(i,checkcol);
		if(board.getSquare(checkhere)->containsPiece())
		{
			i=-1;
			Piece * barrier = board.getSquare(checkhere)->getPiece();
			if(barrier->getColor() != getColor())
			{
				positions.insert(checkhere);
			}
		}
		else
		{
			positions.insert(checkhere);
		}
	}
	//check spaces above in column
	for(int i=checkrow+1; i<8; i++)
	{
		Position checkhere = Position(i,checkcol);
		if(board.getSquare(checkhere)->containsPiece())
		{
			i=8;
			Piece * barrier = board.getSquare(checkhere)->getPiece();
			if(barrier->getColor() != getColor())
			{
				positions.insert(checkhere);
			}
		}
		else
		{
			positions.insert(checkhere);
		}

	}

	return positions;
}

set<Position> Piece::LinearLeftnRight(Board &board)
{
	int checkrow = current.getRow();
	int checkcol = current.getCol();
	set<Position> positions;


	//check spaces left in row
	for(int i=checkcol-1; i>=0; i--)
	{
		Position checkhere = Position(checkrow,i);
		if(board.getSquare(checkhere)->containsPiece())
		{
			i=-1;
			Piece * barrier = board.getSquare(checkhere)->getPiece();
			if(barrier->getColor() != getColor())
			{
				positions.insert(checkhere);
			}
		}
		else
		{
			positions.insert(checkhere);
		}

	}

	//check spaces right in row
	for(int i=checkcol+1; i<8; i++)
	{
		Position checkhere = Position(checkrow,i);
		if(board.getSquare(checkhere)->containsPiece())
		{
			i=8;
			Piece * barrier = board.getSquare(checkhere)->getPiece();
			if(barrier->getColor() != getColor())
			{
				positions.insert(checkhere);
			}
		}
		else
		{
			positions.insert(checkhere);
		}

	}


	return positions;
}

set<Position> Piece::getDiagonalPositions(Board &board)
{
	//int piecerow = current.getRow();
	//int piececol = current.getCol();
	set<Position> positions, first, second;


	first = DiagonalUp(board);
	second = DiagonalDown(board);
	positions = mergePositions(first,second);

	
	return positions;
}


set<Position> Piece::DiagonalUp(Board &board)
{
	int piecerow = current.getRow();
	int piececol = current.getCol();
	set<Position> positions;

	//cout << "Checking up and right" << endl;
	//check up and right
	for(int i=1; i<8; i++)
	{
		if(piecerow-i>=0 && piececol+i<8)
		{
			Position test = Position(piecerow-i,piececol+i);
		
			if(board.getSquare(test)->containsPiece())
			{
				i=8;
				Piece * barrier = board.getSquare(test)->getPiece();
				if(barrier->getColor() != getColor())
				{
					positions.insert(test);
				}
			}
			else
			{
				positions.insert(test);
			}

		}
		else i=8;
	}
	//cout << "Checkin up and left" << endl;
	//check up and left
	for(int i=1; i<8; i++)
	{
		if(piecerow-i>=0 && piececol-i>=0)
		{
			Position test = Position(piecerow-i,piececol-i);
		
			if(board.getSquare(test)->containsPiece())
			{
				i=8;
				Piece * barrier = board.getSquare(test)->getPiece();
				if(barrier->getColor() != getColor())
				{
					positions.insert(test);
				}
			}
			else
			{
				positions.insert(test);
			}

		}
		else i=8;
	}

	return positions;

}

set<Position> Piece::DiagonalDown(Board &board)
{

	int piecerow = current.getRow();
	int piececol = current.getCol();
	set<Position> positions;
	
	
	//cout << "Checking down and right" << endl;
	//check down and right
	for(int i=1;i<8; i++)
	{
		if(piecerow+i<8 && piececol+i<8)
		{
			Position test = Position(piecerow+i,piececol+i);
		
			if(board.getSquare(test)->containsPiece())
			{
				i=8;
				Piece * barrier = board.getSquare(test)->getPiece();
				if(barrier->getColor() != getColor())
				{
					positions.insert(test);
				}
			}
			else
			{
				positions.insert(test);
			}

		}
		else i=8;
	}
	
	//cout << "Checking down and left" << endl;
	//check down and left
	for(int i=1; i<8; i++)
	{
		if(piecerow+i<8 && piececol-i>=0)
		{
			Position test = Position(piecerow+i,piececol-i);
		
			if(board.getSquare(test)->containsPiece())
			{
				i=8;
				Piece * barrier = board.getSquare(test)->getPiece();
				if(barrier->getColor() != getColor())
				{
					positions.insert(test);
				}
			}
			else
			{
				positions.insert(test);
			}

		}
		else i=8;
	}

	return positions;
}

bool Piece::movevalid(Board board, Position moveto)
{
	bool valid = false;
	
	if(board.getSquare(moveto)->containsPiece())
	{
		//i=checkrow;
		Piece * barrier = board.getSquare(moveto)->getPiece();
		if(barrier->getColor() != this->getColor())
		{
			valid = true;			
		}
	}
	else
	{
		valid = true;
	}


	return valid;

}

void Piece::Moving(Position moveto)
{
	previous = current;
	current = moveto;
	moved=true;
}

set<Position> Piece::mergePositions(set<Position> firstset, set<Position> secondset)
{
	set<Position>::iterator iter;
	for(iter=secondset.begin(); iter!=secondset.end(); iter++)
	{
		Position add = *iter;
		firstset.insert(add);
	}

	return firstset;
}
