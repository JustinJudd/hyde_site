#include "Bishop.h"
#include "Pieces.h"

Bishop::Bishop(colors testcolor, Position testposition): Piece(testcolor, testposition)
{
	type = bishop;
}


set<Move> Bishop::getMoves(Board &currentboard)
{

	set<Move> moves;
	set<Position> positions;
	set<Position>::iterator positer;
	positions=getDiagonalPositions(currentboard);

	for(positer = positions.begin(); positer!=positions.end(); positer++)
	{
		Position temp = *positer;
		if(currentboard.getSquare(temp)->containsPiece())
		{
			Piece * piece = currentboard.getSquare(temp)->getPiece();
			moves.insert(createMove(temp, piece->getType()));
		}
		else moves.insert(createMove(temp));
	}
	
	return moves;

}

bool Bishop::Test(ostream &os)
{

	//Bishop will be white, will be at (3,4)
	bool validmoves = false;

	Board board = Board();
	Position start = Position(3,4);
	Piece * testbishop = new Bishop(white, start);

	Square * place = board.getSquare(start);
	
	Position other = Position(4,3);
	Piece * pawnpiece = new Pawn(white, other);
	Piece * rookpiece = new Rook(black, other);

	Square * otherplace = board.getSquare(other);

	place->setPiece(testbishop);

	set<Move> testmoves = testbishop->getMoves(board);

	if(testmoves.size() ==13)
		validmoves = true;
	else os<< "Bishop Test Case 1 failed" << endl;

	otherplace->setPiece(pawnpiece);

	testmoves = testbishop->getMoves(board);

	if(testmoves.size() ==9 &&validmoves)
		validmoves = true;
		
	otherplace->setPiece(rookpiece);

	testmoves = testbishop->getMoves(board);
	if(testmoves.size() ==10 &&validmoves)
	{
		validmoves = true;

	}

	return validmoves;
}
