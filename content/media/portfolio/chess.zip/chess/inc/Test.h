#ifndef CHESSTest_H
#define CHESSTest_H

#include "Piece.h"
#include "Pieces.h"

class Test
{
	main();

};


#endif
