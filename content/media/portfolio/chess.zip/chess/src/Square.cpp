#include "Square.h"
//#include "Pieces.h"


	Square::Square()
	{
		piece=0;
		havePiece=false;
	}

	Square::Square(Piece *newpiece) : piece(newpiece)
	{

		havePiece = true;
	}

	bool Square::containsPiece()
	{
		return havePiece;
	}
	
	
	void Square::setPiece(Piece * newpiece)
	{
		piece = newpiece;
		havePiece=true;
	}
	
	
	Piece * Square::getPiece()
	{
		return piece;
	}
	
	void Square::removePiece()
	{
		if(havePiece)
		{
			//delete piece;
			piece = 0;
			havePiece = false;
		}
	}
	




