#ifndef CHESSKnight_H
#define CHESSKnight_H

#include <set>
#include "Move.h"
#include "Piece.h"
#include "Enums.h"

	

class Knight : public Piece
{

	public:
	
	Knight(colors newcolor, Position newposition);

	virtual set<Move> getMoves(Board &currentboard);
	/* 	find the valid moves for the piece
		parameter: none
		returns: set of valid Move objects
	*/

	static bool Test(ostream &os);


	//Move createMove(Position movehere, PieceType capturedtype);
	//Move createMove(Position movehere);

};


#endif



